"""
Flask-SocketIO Backend for Multiplayer First-Person Mango Slingshot Game
Handles real-time multiplayer, game rooms, hit detection, and telemetry logging
"""

from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit, join_room, leave_room, rooms
from flask_cors import CORS
import random
import time
import json
import csv
import os
from datetime import datetime
from collections import defaultdict

app = Flask(__name__, 
            static_folder='../web-game/static',
            template_folder='../web-game/templates')
CORS(app)
app.config['SECRET_KEY'] = 'archery-game-secret-2025'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Game State
game_rooms = {}  # room_id -> room_data
players = {}     # session_id -> player_data
telemetry_buffer = defaultdict(list)  # player_id -> [events]

# Constants
MAX_PLAYERS_PER_ROOM = 8
STONE_SPEED = 40
GRAVITY = 9.8
MANGO_COUNT_MIN = 10
MANGO_COUNT_MAX = 15


class GameRoom:
    """Manages a multiplayer game room"""
    def __init__(self, room_id, max_players=MAX_PLAYERS_PER_ROOM):
        self.room_id = room_id
        self.max_players = max_players
        self.players = {}  # session_id -> player_state
        self.current_mango = None  # Only one mango visible at a time
        self.total_mangos = random.randint(MANGO_COUNT_MIN, MANGO_COUNT_MAX)
        self.mangos_remaining = self.total_mangos
        self.started = False
        self.start_time = None
        self.scores = defaultdict(int)
        self.game_over = False
        self.game_mode = "NORMAL"  # Track if assisted mode is active
        
    def add_player(self, session_id, player_name):
        """Add player to room"""
        if len(self.players) >= self.max_players:
            return False
        
        # Players in 2D game (no position needed)
        self.players[session_id] = {
            'id': session_id,
            'name': player_name,
            'score': 0,
            'stones_shot': 0,
            'last_shot_time': None,
            'last_shot_position': None
        }
        return True
    
    def remove_player(self, session_id):
        """Remove player from room"""
        if session_id in self.players:
            del self.players[session_id]
    
    def spawn_mango(self):
        """Spawn a new mango on the tree"""
        if self.mangos_remaining <= 0:
            self.game_over = True
            return None
            
        # Mango positions on tree in 2D first-person view (tree centered at x=600, y=200, scaled 1.5x)
        mango = {
            'id': f"mango_{time.time()}",
            'position': {
                'x': random.uniform(500, 700),      # Around tree center (600)
                'y': random.uniform(50, 250)        # Various heights on tree
            },
            'radius': 18,
            'hit': False
        }
        self.current_mango = mango
        return mango
    
    def check_stone_hit(self, stone_data):
        """Check if stone hit the current mango"""
        if not self.current_mango or self.current_mango['hit']:
            return None
            
        stone_pos = stone_data['position']
        mango_pos = self.current_mango['position']
        
        # Calculate 2D distance
        distance = ((stone_pos['x'] - mango_pos['x'])**2 + 
                   (stone_pos['y'] - mango_pos['y'])**2)**0.5
        
        # Check if hit (stone radius + mango radius)
        if distance < 28:  # 8 + 18 + some tolerance
            self.current_mango['hit'] = True
            shooter_id = stone_data.get('shooter_id')
            
            # Award point
            if shooter_id in self.players:
                self.players[shooter_id]['score'] += 1
            
            # Decrease remaining mangos
            self.mangos_remaining -= 1
            
            return {
                'hit': True,
                'mango_id': self.current_mango['id'],
                'shooter_id': shooter_id,
                'mangos_remaining': self.mangos_remaining,
                'game_over': self.mangos_remaining <= 0
            }
        
        return None


@app.route('/')
def index():
    """Serve the game HTML"""
    return render_template('index.html')

@app.route('/api/rooms')
def list_rooms():
    """List available game rooms"""
    rooms_list = []
    for room_id, room in game_rooms.items():
        rooms_list.append({
            'room_id': room_id,
            'players': len(room.players),
            'max_players': room.max_players,
            'started': room.started
        })
    return jsonify({'rooms': rooms_list})


@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    print(f"Client connected: {request.sid}")
    emit('connected', {'session_id': request.sid})


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    print(f"Client disconnected: {request.sid}")
    
    # Remove player from any room
    for room_id, room in list(game_rooms.items()):
        if request.sid in room.players:
            room.remove_player(request.sid)
            leave_room(room_id)
            
            # Notify other players
            emit('player_left', {
                'player_id': request.sid
            }, room=room_id)
            
            # Clean up empty rooms
            if len(room.players) == 0:
                del game_rooms[room_id]
    
    # Save telemetry if exists
    if request.sid in telemetry_buffer:
        save_telemetry(request.sid)


@socketio.on('create_room')
def handle_create_room(data):
    """Create a new game room"""
    room_id = f"room_{int(time.time())}_{random.randint(1000, 9999)}"
    game_rooms[room_id] = GameRoom(room_id)
    
    player_name = data.get('player_name', 'Player')
    
    # Add creator to room
    game_rooms[room_id].add_player(request.sid, player_name)
    join_room(room_id)
    
    emit('room_created', {
        'room_id': room_id,
        'player_id': request.sid
    })
    
    print(f"Room created: {room_id} by {player_name}")


@socketio.on('join_room')
def handle_join_room(data):
    """Join an existing game room"""
    room_id = data.get('room_id')
    player_name = data.get('player_name', 'Player')
    
    if room_id not in game_rooms:
        emit('error', {'message': 'Room not found'})
        return
    
    room = game_rooms[room_id]
    
    if not room.add_player(request.sid, player_name):
        emit('error', {'message': 'Room is full'})
        return
    
    join_room(room_id)
    
    # Send current room state to new player
    emit('room_joined', {
        'room_id': room_id,
        'player_id': request.sid,
        'players': room.players,
        'current_mango': room.current_mango,
        'total_mangos': room.total_mangos,
        'mangos_remaining': room.mangos_remaining
    })
    
    # Notify other players
    emit('player_joined', {
        'player_id': request.sid,
        'player_data': room.players[request.sid]
    }, room=room_id, skip_sid=request.sid)
    
    print(f"Player {player_name} joined room {room_id}")


@socketio.on('player_update')
def handle_player_update(data):
    """Update player state (not needed in 2D game)"""
    pass  # Players don't move in 2D slingshot game


@socketio.on('shoot_stone')
def handle_shoot_stone(data):
    """Handle stone shot"""
    room_id = data.get('room_id')
    
    if room_id not in game_rooms:
        return
    
    room = game_rooms[room_id]
    if request.sid not in room.players:
        return
    
    player = room.players[request.sid]
    
    # Calculate reaction time (time since last shot or mango spawn)
    current_time = time.time()
    if player['last_shot_time'] is None:
        reaction_time_ms = 0  # First shot
    else:
        reaction_time_ms = (current_time - player['last_shot_time']) * 1000
    
    # Get shot position and target
    shot_position = data.get('position', {})
    shot_x = shot_position.get('x', 0)
    shot_y = shot_position.get('y', 0)
    
    target_x = 0
    target_y = 0
    distance_to_target = 0
    if room.current_mango:
        target_x = room.current_mango['position']['x']
        target_y = room.current_mango['position']['y']
        distance_to_target = ((shot_x - target_x)**2 + (shot_y - target_y)**2)**0.5
    
    # Calculate mouse speed (distance from last shot position)
    mouse_speed = 0
    if player['last_shot_position']:
        last_x = player['last_shot_position'].get('x', 0)
        last_y = player['last_shot_position'].get('y', 0)
        mouse_speed = ((shot_x - last_x)**2 + (shot_y - last_y)**2)**0.5
    
    # Calculate aim snap distance (distance between aim point and target)
    aim_snap_distance = distance_to_target
    
    # Store shot data for next calculation
    player['last_shot_time'] = current_time
    player['last_shot_position'] = {'x': shot_x, 'y': shot_y}
    player['stones_shot'] += 1
    
    # Store shot data temporarily (will be updated when we know if it hit)
    telemetry_event = {
        'timestamp': datetime.now().isoformat(),
        'player_id': request.sid,
        'player_name': player['name'],
        'game_mode': room.game_mode,
        'shot_x': shot_x,
        'shot_y': shot_y,
        'target_x': target_x,
        'target_y': target_y,
        'hit': 0,  # Will be updated on hit
        'reaction_time_ms': reaction_time_ms,
        'distance_to_target': distance_to_target,
        'mouse_speed': mouse_speed,
        'aim_snap_distance': aim_snap_distance
    }
    telemetry_buffer[request.sid].append(telemetry_event)
    
    # Broadcast stone to all players
    stone_data = {
        'id': f"stone_{request.sid}_{time.time()}",
        'shooter_id': request.sid,
        'position': data.get('position'),
        'velocity': data.get('velocity')
    }
    
    emit('stone_shot', stone_data, room=room_id)
    
    print(f"Stone shot by {request.sid} in room {room_id}")


@socketio.on('stone_hit')
def handle_stone_hit(data):
    """Handle stone collision detection"""
    room_id = data.get('room_id')
    
    if room_id not in game_rooms:
        return
    
    room = game_rooms[room_id]
    stone_data = data.get('stone_data')
    
    hit_result = room.check_stone_hit(stone_data)
    
    if hit_result:
        shooter_id = stone_data.get('shooter_id')
        
        # Update the last telemetry event to mark as hit
        if shooter_id in telemetry_buffer and telemetry_buffer[shooter_id]:
            telemetry_buffer[shooter_id][-1]['hit'] = 1
        
        # Mango was hit!
        emit('mango_hit', {
            'stone_id': stone_data.get('id'),
            'hit_result': {
                **hit_result,
                'total_mangos': room.total_mangos
            },
            'scores': {pid: p['score'] for pid, p in room.players.items()}
        }, room=room_id)
        
        # Check if game over
        if hit_result['game_over']:
            emit('game_over', {
                'scores': {pid: p['score'] for pid, p in room.players.items()},
                'total_stones': {pid: p['stones_shot'] for pid, p in room.players.items()}
            }, room=room_id)
        else:
            # Spawn next mango after short delay
            time.sleep(0.5)
            new_mango = room.spawn_mango()
            if new_mango:
                emit('mango_spawned', {
                    'mango': new_mango,
                    'total_mangos': room.total_mangos,
                    'mangos_remaining': room.mangos_remaining
                }, room=room_id)


@socketio.on('request_mango')
def handle_request_mango(data):
    """Spawn first mango or request current mango"""
    room_id = data.get('room_id')
    
    if room_id not in game_rooms:
        return
    
    room = game_rooms[room_id]
    
    # If no mango exists, spawn one
    if not room.current_mango:
        mango = room.spawn_mango()
        if mango:
            emit('mango_spawned', {
                'mango': mango,
                'total_mangos': room.total_mangos,
                'mangos_remaining': room.mangos_remaining
            }, room=room_id)
    else:
        # Send current mango to requester
        emit('mango_spawned', {
            'mango': room.current_mango,
            'total_mangos': room.total_mangos,
            'mangos_remaining': room.mangos_remaining
        })


@socketio.on('set_game_mode')
def handle_set_game_mode(data):
    """Set game mode to NORMAL or ASSISTED for cheat detection"""
    room_id = data.get('room_id')
    mode = data.get('mode', 'NORMAL')
    
    if room_id not in game_rooms:
        return
    
    room = game_rooms[room_id]
    room.game_mode = mode
    
    print(f"Game mode set to {mode} for room {room_id}")


def save_telemetry(player_id):
    """Save player telemetry to CSV"""
    if player_id not in telemetry_buffer or len(telemetry_buffer[player_id]) == 0:
        return
    
    logs_dir = 'logs'
    os.makedirs(logs_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(logs_dir, f'player_{player_id[:8]}_{timestamp}.csv')
    
    # Use column names that match AI model expectations
    fieldnames = ['timestamp', 'player_id', 'player_name', 'game_mode', 'shot_x', 'shot_y', 
                  'target_x', 'target_y', 'hit', 'reaction_time_ms', 
                  'distance_to_target', 'mouse_speed', 'aim_snap_distance']
    
    with open(filename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for event in telemetry_buffer[player_id]:
            writer.writerow(event)
    
    print(f"Saved telemetry for player {player_id}: {filename}")
    del telemetry_buffer[player_id]


if __name__ == '__main__':
    import socket
    
    # Get local IP address
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except:
        local_ip = '127.0.0.1'
    
    print("\n" + "="*60)
    print("  🥭 MULTIPLAYER MANGO SLINGSHOT GAME SERVER")
    print("="*60)
    print("\n  🎮 SERVER RUNNING!")
    print(f"\n  Local access:    http://localhost:5000")
    print(f"  LAN access:      http://{local_ip}:5000")
    print("\n  📱 For LAN multiplayer:")
    print(f"     Share this URL with players on your WiFi:")
    print(f"     → http://{local_ip}:5000")
    print("\n" + "="*60 + "\n")
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)
