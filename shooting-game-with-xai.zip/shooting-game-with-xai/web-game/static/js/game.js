// Multiplayer 2D Mango Slingshot Game Client
// HTML5 Canvas 2D with Socket.io multiplayer

// Global variables
let canvas, ctx, socket;
let playerName, playerId, currentRoom;
let gameStarted = false;

// Game objects
let slingshotPulled = false;
let stones = [];
let currentMango = null;
let totalMangos = 0;
let mangosRemaining = 0;

// Other players
let otherPlayers = {};

// Mouse state
let mouseX = 0;
let mouseY = 0;
let mouseDown = false;

// Physics constants
const GRAVITY = 980;
const STONE_RADIUS = 8;
const MANGO_RADIUS = 15;
const SHOT_SPEED = 1250; // Fixed shot speed (pull distance does not affect range)
const MAX_RUBBER_STRETCH = 60; // Maximum distance rubber band can be pulled

// Game world dimensions (first-person view)
const SLINGSHOT_BASE_Y = 520; // Bottom of screen (your hands)
const SLINGSHOT_CENTER_X = 600; // Hand in center
const TREE_X = 600; // Center of screen
const TREE_Y = 230; // Distance perspective (tuned to keep canopy on-screen)
const TREE_SCALE = 1.8; // Tuned to avoid top clipping while keeping mango alignment reasonable
const CROSSHAIR_X = 600; // Fixed center crosshair
const CROSSHAIR_Y = 300; // Fixed center crosshair

function safeNumber(value, fallback = 0) {
    const num = Number(value);
    return Number.isFinite(num) ? num : fallback;
}

function updateMangoCounter() {
    const total = safeNumber(totalMangos, 0);
    const remaining = safeNumber(mangosRemaining, total);
    const collected = Math.max(0, total - remaining);
    document.getElementById('mangos-count').textContent = `${collected}/${total}`;
}

// Initialize
window.addEventListener('load', init);

function init() {
    console.log('Initializing 2D mango slingshot game...');
    
    const serverUrl = `${window.location.protocol}//${window.location.host}`;
    console.log('Connecting to server:', serverUrl);
    socket = io(serverUrl);
    
    socket.on('connected', (data) => {
        playerId = data.session_id;
        console.log('Connected to server:', playerId);
    });
    
    socket.on('room_created', handleRoomCreated);
    socket.on('room_joined', handleRoomJoined);
    socket.on('player_joined', handlePlayerJoined);
    socket.on('player_left', handlePlayerLeft);
    socket.on('stone_shot', handleStoneShot);
    socket.on('mango_hit', handleMangoHit);
    socket.on('mango_spawned', handleMangoSpawned);
    socket.on('game_over', handleGameOver);
    socket.on('error', (data) => {
        alert('Error: ' + data.message);
    });
}

function createRoom() {
    playerName = document.getElementById('player-name').value.trim() || 'Player';
    socket.emit('create_room', { player_name: playerName });
}

function showRoomList() {
    const roomListDiv = document.getElementById('room-list');
    roomListDiv.classList.toggle('hidden');
    
    // Fetch available rooms from server
    if (!roomListDiv.classList.contains('hidden')) {
        fetchAvailableRooms();
    }
}

function fetchAvailableRooms() {
    fetch('/api/rooms')
        .then(response => response.json())
        .then(data => {
            const roomsContainer = document.getElementById('rooms-container');
            roomsContainer.innerHTML = '';
            
            if (data.rooms.length === 0) {
                roomsContainer.innerHTML = '<p style="color: #ddd;">No rooms available</p>';
                return;
            }
            
            data.rooms.forEach(room => {
                const roomDiv = document.createElement('div');
                roomDiv.style.cssText = 'background: rgba(255,255,255,0.1); padding: 10px; margin: 5px 0; border-radius: 5px; cursor: pointer;';
                roomDiv.innerHTML = `
                    <strong>${room.room_id}</strong><br>
                    Players: ${room.players}/${room.max_players} ${room.started ? '(In Progress)' : ''}
                `;
                
                if (!room.started && room.players < room.max_players) {
                    roomDiv.onclick = () => {
                        document.getElementById('room-id-input').value = room.room_id;
                    };
                    roomDiv.style.cursor = 'pointer';
                } else {
                    roomDiv.style.opacity = '0.5';
                    roomDiv.style.cursor = 'not-allowed';
                }
                
                roomsContainer.appendChild(roomDiv);
            });
        })
        .catch(error => {
            console.error('Error fetching rooms:', error);
            document.getElementById('rooms-container').innerHTML = '<p style="color: #ff6b6b;">Error loading rooms</p>';
        });
}

function joinRoom() {
    playerName = document.getElementById('player-name').value.trim() || 'Player';
    const roomId = document.getElementById('room-id-input').value.trim();
    if (!roomId) {
        alert('Please enter a room ID');
        return;
    }
    socket.emit('join_room', { room_id: roomId, player_name: playerName });
}

function handleRoomCreated(data) {
    currentRoom = data.room_id;
    document.getElementById('menu-screen').classList.add('hidden');
    document.getElementById('lobby-screen').classList.remove('hidden');
    document.getElementById('room-id-display').textContent = currentRoom;
    updatePlayerList();
}

function handleRoomJoined(data) {
    currentRoom = data.room_id;
    playerId = data.player_id;
    totalMangos = safeNumber(data.total_mangos, 0);
    mangosRemaining = safeNumber(data.mangos_remaining, totalMangos);
    
    document.getElementById('menu-screen').classList.add('hidden');
    document.getElementById('lobby-screen').classList.remove('hidden');
    document.getElementById('room-id-display').textContent = currentRoom;
    
    for (let pid in data.players) {
        if (pid !== playerId) {
            otherPlayers[pid] = data.players[pid];
        }
    }
    
    updatePlayerList();
    updateMangoCounter();
}

function handlePlayerJoined(data) {
    otherPlayers[data.player_id] = data.player_data;
    updatePlayerList();
}

function handlePlayerLeft(data) {
    delete otherPlayers[data.player_id];
    updatePlayerList();
}

function updatePlayerList() {
    const playerList = document.getElementById('player-list');
    const playerCount = Object.keys(otherPlayers).length + 1;
    
    let html = `<div style="margin-bottom: 10px;"><strong>Players (${playerCount}/8):</strong></div>`;
    html += `<div class="player-item">🥭 ${playerName} (You)</div>`;
    
    for (let pid in otherPlayers) {
        html += `<div class="player-item">🥭 ${otherPlayers[pid].name}</div>`;
    }
    
    playerList.innerHTML = html;
}

function startGame() {
    gameStarted = true;
    document.getElementById('lobby-screen').classList.add('hidden');
    
    // Show canvas and start game
    document.getElementById('game-canvas').classList.remove('hidden');
    
    initCanvas();
    
    socket.emit('request_mango', { room_id: currentRoom });
    
    document.getElementById('hud').classList.remove('hidden');
    document.getElementById('scoreboard').classList.remove('hidden');
    updateMangoCounter();
    
    // Start game loop AFTER canvas is initialized
    gameLoop();
}

function initCanvas() {
    canvas = document.getElementById('game-canvas');
    ctx = canvas.getContext('2d');
    
    canvas.width = 1200;
    canvas.height = 600;
    
    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mousedown', onMouseDown);
    canvas.addEventListener('mouseup', onMouseUp);
    window.addEventListener('resize', onWindowResize);
    
    onWindowResize();
}

function onWindowResize() {
    const container = document.getElementById('game-container');
    const scale = Math.min(
        container.clientWidth / canvas.width,
        container.clientHeight / canvas.height
    );
    canvas.style.transform = `translate(-50%, -50%) scale(${scale})`;
}

function onMouseMove(event) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    mouseX = (event.clientX - rect.left) * scaleX;
    mouseY = (event.clientY - rect.top) * scaleY;
}

function onMouseDown(event) {
    onMouseMove(event);
    if (event.button === 0) {
        mouseDown = true;
        slingshotPulled = true;
    }
}

function onMouseUp(event) {
    onMouseMove(event);
    if (event.button === 0 && slingshotPulled) {
        shootStone();
        mouseDown = false;
        slingshotPulled = false;
    }
}

function shootStone() {
    if (!gameStarted) return;

    // Launch based on the rubber-band pull vector.
    // Rest (unpulled) pouch position matches the relaxed band curve.
    const restX = SLINGSHOT_CENTER_X;
    const restY = SLINGSHOT_BASE_Y - 80;

    // Use the last mouse position as the pulled pouch position, clamped to max stretch.
    let pouchX = mouseX;
    let pouchY = mouseY;
    
    // Clamp pull distance to MAX_RUBBER_STRETCH
    const pullDist = Math.sqrt((pouchX - restX) ** 2 + (pouchY - restY) ** 2);
    if (pullDist > MAX_RUBBER_STRETCH) {
        const ratio = MAX_RUBBER_STRETCH / pullDist;
        pouchX = restX + (pouchX - restX) * ratio;
        pouchY = restY + (pouchY - restY) * ratio;
    }

    // Projectile goes in the opposite direction of the pull.
    const pullDx = restX - pouchX;
    const pullDy = restY - pouchY;
    const pullDistance = Math.sqrt(pullDx * pullDx + pullDy * pullDy);

    if (!Number.isFinite(pullDistance) || pullDistance < 1) {
        return;
    }

    // Fixed speed: only direction comes from pull.
    const velocityX = (pullDx / pullDistance) * SHOT_SPEED;
    const velocityY = (pullDy / pullDistance) * SHOT_SPEED;
    
    const stone = {
        x: pouchX,
        y: pouchY,
        vx: velocityX,
        vy: velocityY,
        lifetime: 0,
        shooter_id: playerId
    };
    
    stones.push(stone);
    
    socket.emit('shoot_stone', {
        room_id: currentRoom,
        position: { x: stone.x, y: stone.y },
        velocity: { x: velocityX, y: velocityY }
    });
}

function handleStoneShot(data) {
    if (data.shooter_id === playerId) return;
    
    const stone = {
        x: data.position.x,
        y: data.position.y,
        vx: data.velocity.x,
        vy: data.velocity.y,
        lifetime: 0,
        shooter_id: data.shooter_id,
        networkStone: true
    };
    
    stones.push(stone);
}

function handleMangoSpawned(data) {
    console.log('Mango spawned:', data.mango);
    currentMango = data.mango;
    totalMangos = safeNumber(data.total_mangos, totalMangos);
    const defaultRemaining = totalMangos > 0 ? totalMangos : 0;
    mangosRemaining = safeNumber(data.mangos_remaining, defaultRemaining);

    updateMangoCounter();
}

function handleMangoHit(data) {
    console.log('Mango hit!', data);
    
    if (currentMango) {
        animateMangoFall();
    }
    
    updateScoreboard(data.scores);
    
    // Update mango counts from server data
    if (data.hit_result) {
        mangosRemaining = safeNumber(data.hit_result.mangos_remaining, 0);
        totalMangos = safeNumber(data.hit_result.total_mangos, totalMangos);
    }
    
    updateMangoCounter();
}

function animateMangoFall() {
    currentMango = null;
}

function handleGameOver(data) {
    console.log('Game over!', data);
    gameStarted = false;
    
    const scores = data.scores;
    const stonesShot = data.total_stones;
    
    let html = '<div style="background: rgba(0,0,0,0.9); padding: 30px; border-radius: 10px;">';
    html += '<h1 style="color: #ffa500;">🥭 GAME OVER! 🥭</h1>';
    html += '<h2 style="color: #feca57;">Final Scores:</h2>';
    
    const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    
    sortedScores.forEach(([pid, score], index) => {
        const name = pid === playerId ? playerName : (otherPlayers[pid]?.name || 'Player');
        const accuracy = stonesShot[pid] > 0 ? ((score / stonesShot[pid]) * 100).toFixed(1) : 0;
        html += `<p style="font-size: 20px; color: white;">${index + 1}. ${name}: ${score} mangos (${accuracy}% accuracy)</p>`;
    });
    
    html += '<div style="margin-top: 20px;">';
    html += '<button onclick="location.reload()" style="padding: 10px 30px; font-size: 18px; margin: 5px;">Play Again</button>';
    html += '<button onclick="goBackToMenu()" style="padding: 10px 30px; font-size: 18px; margin: 5px; background: linear-gradient(45deg, #667eea, #764ba2);">Back to Menu</button>';
    html += '</div>';
    html += '</div>';
    
    document.getElementById('game-over-screen').innerHTML = html;
    document.getElementById('game-over-screen').classList.remove('hidden');
}

function goBackToMenu() {
    location.reload();
}

function updateScoreboard(scores) {
    const scoreboard = document.getElementById('scoreboard-list');
    let html = '';
    
    const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    
    for (let [pid, score] of sortedScores) {
        const name = pid === playerId ? playerName : (otherPlayers[pid]?.name || 'Player');
        html += `<div class="score-entry"><span>${name}</span><span>${score}</span></div>`;
    }
    
    scoreboard.innerHTML = html;
    
    if (scores[playerId] !== undefined) {
        document.getElementById('score').textContent = scores[playerId];
    }
}

function drawSky() {
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#87CEEB');
    gradient.addColorStop(1, '#E0F6FF');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function drawGround() {
    ctx.fillStyle = '#2d5016';
    ctx.fillRect(0, 520, canvas.width, 80);
    
    ctx.fillStyle = '#3a6b1f';
    for (let i = 0; i < canvas.width; i += 10) {
        ctx.fillRect(i, 520, 5, 10);
    }
}

function drawMangoTree() {
    ctx.save();
    ctx.translate(TREE_X, TREE_Y);
    ctx.scale(TREE_SCALE, TREE_SCALE);

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.beginPath();
    ctx.ellipse(0, 85, 65, 16, 0, 0, Math.PI * 2);
    ctx.fill();

    // Tree trunk (simple, clean cartoon)
    ctx.fillStyle = '#5D4037';
    ctx.beginPath();
    ctx.moveTo(-25, 85);
    ctx.quadraticCurveTo(-15, 45, -20, 5);
    ctx.lineTo(-20, -30);
    ctx.lineTo(20, -30);
    ctx.lineTo(20, 5);
    ctx.quadraticCurveTo(15, 45, 25, 85);
    ctx.closePath();
    ctx.fill();

    // Trunk texture/details
    ctx.strokeStyle = '#3E2723';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-10, 65);
    ctx.quadraticCurveTo(0, 55, -6, 35);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(10, 75);
    ctx.quadraticCurveTo(6, 55, 12, 45);
    ctx.stroke();

    // Branches
    ctx.strokeStyle = '#5D4037';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, -5);
    ctx.lineTo(-45, -40);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, 5);
    ctx.lineTo(45, -35);
    ctx.stroke();

    // Foliage - multiple circles for a friendly, consistent look
    const leaves = [
        // Bottom layer (darker) - widened canopy
        { x: -75, y: -20, r: 46, color: '#1B5E20' },
        { x: 75, y: -20, r: 46, color: '#1B5E20' },
        { x: -35, y: -25, r: 44, color: '#1B5E20' },
        { x: 35, y: -25, r: 44, color: '#1B5E20' },
        { x: 0, y: -32, r: 50, color: '#1B5E20' },

        // Middle layer
        { x: -55, y: -55, r: 46, color: '#2E7D32' },
        { x: 55, y: -55, r: 46, color: '#2E7D32' },
        { x: -95, y: -40, r: 40, color: '#2E7D32' },
        { x: 95, y: -40, r: 40, color: '#2E7D32' },

        // Top layer (lighter)
        { x: 0, y: -78, r: 50, color: '#388E3C' },
        { x: -50, y: -70, r: 46, color: '#43A047' },
        { x: 50, y: -70, r: 46, color: '#43A047' },
        { x: 0, y: -52, r: 44, color: '#4CAF50' }
    ];

    leaves.forEach(leaf => {
        ctx.fillStyle = leaf.color;
        ctx.beginPath();
        ctx.arc(leaf.x, leaf.y, leaf.r, 0, Math.PI * 2);
        ctx.fill();

        // Highlight on leaves
        ctx.fillStyle = 'rgba(255,255,255,0.10)';
        ctx.beginPath();
        ctx.arc(leaf.x - leaf.r * 0.3, leaf.y - leaf.r * 0.3, leaf.r * 0.42, 0, Math.PI * 2);
        ctx.fill();
    });

    ctx.restore();
}

function drawSlingshot() {
    // Draw first-person slingshot (frame + band only)
    ctx.save();
    
    const handX = SLINGSHOT_CENTER_X;
    const handY = SLINGSHOT_BASE_Y;
    
    // Slingshot Y-frame (wooden)
    ctx.strokeStyle = '#8B4513';
    ctx.lineWidth = 14;
    ctx.lineCap = 'round';
    
    // Handle (hidden by hand mostly)
    ctx.beginPath();
    ctx.moveTo(handX, handY + 60);
    ctx.lineTo(handX, handY - 20);
    ctx.stroke();
    
    // Left prong
    ctx.beginPath();
    ctx.moveTo(handX, handY - 20);
    ctx.quadraticCurveTo(handX - 10, handY - 50, handX - 50, handY - 100);
    ctx.stroke();
    
    // Right prong
    ctx.beginPath();
    ctx.moveTo(handX, handY - 20);
    ctx.quadraticCurveTo(handX + 10, handY - 50, handX + 50, handY - 100);
    ctx.stroke();
    
    // Rubber band
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 4;
    
    if (slingshotPulled && mouseDown) {
        // Clamp pull distance to MAX_RUBBER_STRETCH
        const restX = handX;
        const restY = handY - 80;
        let clampedMouseX = mouseX;
        let clampedMouseY = mouseY;
        
        const pullDist = Math.sqrt((mouseX - restX) ** 2 + (mouseY - restY) ** 2);
        if (pullDist > MAX_RUBBER_STRETCH) {
            const ratio = MAX_RUBBER_STRETCH / pullDist;
            clampedMouseX = restX + (mouseX - restX) * ratio;
            clampedMouseY = restY + (mouseY - restY) * ratio;
        }
        
        // Pulled back rubber band
        ctx.beginPath();
        ctx.moveTo(handX - 50, handY - 100);
        ctx.lineTo(clampedMouseX, clampedMouseY);
        ctx.lineTo(handX + 50, handY - 100);
        ctx.stroke();
        
        // Stone in pouch
        ctx.fillStyle = '#555';
        ctx.strokeStyle = '#222';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(clampedMouseX, clampedMouseY, STONE_RADIUS + 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        
        // Pouch itself
        ctx.fillStyle = '#4E342E';
        ctx.beginPath();
        ctx.ellipse(clampedMouseX, clampedMouseY, 12, 12, 0, 0, Math.PI * 2);
        ctx.fill();
        
    } else {
        // Relaxed rubber band
        ctx.beginPath();
        ctx.moveTo(handX - 50, handY - 100);
        ctx.quadraticCurveTo(handX, handY - 80, handX + 50, handY - 100);
        ctx.stroke();
        
    }
    
    ctx.restore();
}

function drawMango(mango) {
    if (!mango) return;
    
    ctx.save();
    
    const gradient = ctx.createRadialGradient(mango.position.x, mango.position.y - 5, 5, mango.position.x, mango.position.y, MANGO_RADIUS);
    gradient.addColorStop(0, '#FFD700');
    gradient.addColorStop(0.7, '#FFA500');
    gradient.addColorStop(1, '#FF8C00');
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.ellipse(mango.position.x, mango.position.y, MANGO_RADIUS, MANGO_RADIUS * 1.2, 0.3, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.beginPath();
    ctx.arc(mango.position.x - 8, mango.position.y - 8, 6, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.strokeStyle = '#228B22';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(mango.position.x, mango.position.y - MANGO_RADIUS * 1.2);
    ctx.lineTo(mango.position.x - 5, mango.position.y - MANGO_RADIUS * 1.2 - 10);
    ctx.stroke();
    
    ctx.restore();
}

function drawStone(stone) {
    ctx.fillStyle = '#666';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    
    ctx.beginPath();
    ctx.arc(stone.x, stone.y, STONE_RADIUS, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
}

function gameLoop() {
    if (!gameStarted) return;
    
    const deltaTime = 1/60;
    
    drawSky();
    drawGround();
    drawMangoTree();
    
    if (currentMango) {
        drawMango(currentMango);
    }
    
    // Update and draw stones
    for (let i = stones.length - 1; i >= 0; i--) {
        const stone = stones[i];
        
        stone.vy += GRAVITY * deltaTime;
        
        stone.x += stone.vx * deltaTime;
        stone.y += stone.vy * deltaTime;
        
        stone.lifetime += deltaTime;
        
        if (stone.y > canvas.height || stone.x > canvas.width || stone.x < 0 || stone.lifetime > 5) {
            stones.splice(i, 1);
            continue;
        }
        
        if (currentMango && !stone.networkStone) {
            const dx = stone.x - currentMango.position.x;
            const dy = stone.y - currentMango.position.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < STONE_RADIUS + MANGO_RADIUS) {
                socket.emit('stone_hit', {
                    room_id: currentRoom,
                    stone_data: {
                        id: 'stone_' + Date.now(),
                        shooter_id: playerId,
                        position: { x: stone.x, y: stone.y }
                    }
                });
                
                stones.splice(i, 1);
                continue;
            }
        }
        
        drawStone(stone);
    }
    
    drawSlingshot();
    drawTrajectory();
    
    requestAnimationFrame(gameLoop);
}

function drawTrajectory() {
    if (!slingshotPulled || !mouseDown) return;

    const restX = SLINGSHOT_CENTER_X;
    const restY = SLINGSHOT_BASE_Y - 80;
    
    // Clamp pull distance to MAX_RUBBER_STRETCH (same as in shootStone and drawSlingshot)
    let pouchX = mouseX;
    let pouchY = mouseY;
    
    const pullDist = Math.sqrt((pouchX - restX) ** 2 + (pouchY - restY) ** 2);
    if (pullDist > MAX_RUBBER_STRETCH) {
        const ratio = MAX_RUBBER_STRETCH / pullDist;
        pouchX = restX + (pouchX - restX) * ratio;
        pouchY = restY + (pouchY - restY) * ratio;
    }

    const pullDx = restX - pouchX;
    const pullDy = restY - pouchY;
    const pullDistance = Math.sqrt(pullDx * pullDx + pullDy * pullDy);
    
    if (!Number.isFinite(pullDistance) || pullDistance < 1) return;

    const vx0 = (pullDx / pullDistance) * SHOT_SPEED;
    const vy0 = (pullDy / pullDistance) * SHOT_SPEED;

    let x = pouchX;
    let y = pouchY;
    let vx = vx0;
    let vy = vy0;
    
    const dt = 1 / 60;
    const maxSteps = 180; // 3 seconds prediction

    ctx.save();
    
    for (let i = 0; i < maxSteps; i++) {
        vy += GRAVITY * dt;
        x += vx * dt;
        y += vy * dt;

        // Check mango hit
        if (currentMango) {
             const dx = x - currentMango.position.x;
             const dy = y - currentMango.position.y;
             const dist = Math.sqrt(dx*dx + dy*dy);
             if (dist < STONE_RADIUS + MANGO_RADIUS) {
                 // Draw hit indicator
                 ctx.fillStyle = 'rgba(255, 50, 50, 0.8)';
                 ctx.strokeStyle = 'white';
                 ctx.lineWidth = 2;
                 ctx.beginPath();
                 ctx.arc(x, y, 12, 0, Math.PI*2);
                 ctx.fill();
                 ctx.stroke();
                 break; // Stop trajectory at hit
             }
        }

        // Check ground hit
        if (y >= canvas.height) {
            break;
        }
        
        // Draw trajectory dots - more frequent near start, less frequent later
        let shouldDraw = false;
        if (i < 30) {
            // First 0.5 seconds: draw every 2 steps (dense near start)
            shouldDraw = (i % 2 === 0);
        } else if (i < 60) {
            // Next 0.5 seconds: draw every 3 steps
            shouldDraw = (i % 3 === 0);
        } else {
            // After 1 second: draw every 5 steps (sparse)
            shouldDraw = (i % 5 === 0);
        }
        
        if (shouldDraw) {
            // Fade dots over distance
            const alpha = Math.max(0.3, 1 - (i / maxSteps));
            ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI*2);
            ctx.fill();
        }
    }
    
    ctx.restore();
}

function drawCrosshair() {
    // Fixed crosshair in center of screen
    ctx.save();
    
    const cx = CROSSHAIR_X;
    const cy = CROSSHAIR_Y;
    
    // Outer circle
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy, 20, 0, Math.PI * 2);
    ctx.stroke();
    
    // Inner circle
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, 12, 0, Math.PI * 2);
    ctx.stroke();
    
    // Crosshair lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 2;
    
    // Top
    ctx.beginPath();
    ctx.moveTo(cx, cy - 25);
    ctx.lineTo(cx, cy - 35);
    ctx.stroke();
    
    // Bottom
    ctx.beginPath();
    ctx.moveTo(cx, cy + 25);
    ctx.lineTo(cx, cy + 35);
    ctx.stroke();
    
    // Left
    ctx.beginPath();
    ctx.moveTo(cx - 25, cy);
    ctx.lineTo(cx - 35, cy);
    ctx.stroke();
    
    // Right
    ctx.beginPath();
    ctx.moveTo(cx + 25, cy);
    ctx.lineTo(cx + 35, cy);
    ctx.stroke();
    
    // Center dot
    ctx.fillStyle = 'rgba(255, 0, 0, 0.8)';
    ctx.beginPath();
    ctx.arc(cx, cy, 3, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();
}

function leaveRoom() {
    location.reload();
}
