// Auto-Shoot Hack for Mango Slingshot Game
// Paste this into the browser console (F12) for demo/testing purposes

(function() {
    // Check if hack is already injected
    if (window.mangoHackInjected) {
        console.log('Hack already injected!');
        return;
    }
    window.mangoHackInjected = true;
    
    // Notify server that assisted mode is active
    if (typeof socket !== 'undefined' && currentRoom) {
        socket.emit('set_game_mode', {
            room_id: currentRoom,
            mode: 'ASSISTED'
        });
        console.log('Notified server: ASSISTED mode active');
    }

    // Create hack UI button
    const hackButton = document.createElement('button');
    hackButton.innerHTML = '🎯 AUTO SHOOT';
    hackButton.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 10000;
        padding: 15px 25px;
        font-size: 18px;
        font-weight: bold;
        background: linear-gradient(45deg, #ff0000, #ff6b00);
        color: white;
        border: 3px solid #ffff00;
        border-radius: 10px;
        cursor: pointer;
        box-shadow: 0 4px 15px rgba(255, 0, 0, 0.5);
        transition: all 0.3s;
    `;

    hackButton.onmouseover = function() {
        this.style.transform = 'scale(1.1)';
        this.style.boxShadow = '0 6px 20px rgba(255, 0, 0, 0.8)';
    };

    hackButton.onmouseout = function() {
        this.style.transform = 'scale(1)';
        this.style.boxShadow = '0 4px 15px rgba(255, 0, 0, 0.5)';
    };

    hackButton.onclick = function() {
        if (!gameStarted) {
            alert('Game not started yet!');
            return;
        }

        if (!currentMango) {
            alert('No mango to shoot!');
            return;
        }

        // Search parameters based on mango position
        const restX = SLINGSHOT_CENTER_X;
        const restY = SLINGSHOT_BASE_Y - 80;
        const targetX = currentMango.position.x;
        const targetY = currentMango.position.y;

        // Determine general direction to aim
        const toTargetX = targetX - restX;
        const toTargetY = targetY - restY;
        const baseAngle = Math.atan2(toTargetY, toTargetX);

        let bestPouchX = mouseX;
        let bestPouchY = mouseY;
        let bestDist = Infinity;
        let bestHitTime = Infinity;

        // Search around the general direction (pull OPPOSITE to target)
        for (let angleOffset = -0.8; angleOffset < 0.8; angleOffset += 0.01) {
            const angle = baseAngle + Math.PI + angleOffset; // +PI to pull opposite
            
            for (let dist = 140; dist <= 200; dist += 5) {
                let pouchX = restX + Math.cos(angle) * dist;
                let pouchY = restY + Math.sin(angle) * dist;

                // Clamp to max stretch
                const pullDist = Math.sqrt((pouchX - restX) ** 2 + (pouchY - restY) ** 2);
                if (pullDist > MAX_RUBBER_STRETCH) {
                    const ratio = MAX_RUBBER_STRETCH / pullDist;
                    pouchX = restX + (pouchX - restX) * ratio;
                    pouchY = restY + (pouchY - restY) * ratio;
                }

                // Calculate shot velocity
                const pullDx = restX - pouchX;
                const pullDy = restY - pouchY;
                const pullMag = Math.sqrt(pullDx * pullDx + pullDy * pullDy);

                if (pullMag < 1) continue;

                const vx = (pullDx / pullMag) * SHOT_SPEED;
                const vy = (pullDy / pullMag) * SHOT_SPEED;

                // Simulate
                let x = pouchX;
                let y = pouchY;
                let svx = vx;
                let svy = vy;

                let closestDist = Infinity;
                let hitTime = -1;
                for (let t = 0; t < 180; t++) {
                    svy += GRAVITY / 60;
                    x += svx / 60;
                    y += svy / 60;

                    const d = Math.sqrt((x - targetX)**2 + (y - targetY)**2);
                    
                    if (d < closestDist) {
                        closestDist = d;
                        hitTime = t;
                    }
                    
                    // Stop at first very close approach (ascending trajectory)
                    if (d < STONE_RADIUS + MANGO_RADIUS + 3) {
                        break;
                    }

                    if (y > canvas.height || x < 0 || x > canvas.width) break;
                }

                // Select based on closest distance, preferring earlier hits when distance is similar
                const isBetter = (closestDist < bestDist - 1) || 
                                (Math.abs(closestDist - bestDist) < 1 && hitTime < bestHitTime);
                
                if (isBetter) {
                    bestDist = closestDist;
                    bestHitTime = hitTime;
                    bestPouchX = pouchX;
                    bestPouchY = pouchY;
                }
            }
        }

        // Set position and shoot
        mouseX = bestPouchX;
        mouseY = bestPouchY;
        
        // Simulate pull and release
        mouseDown = true;
        slingshotPulled = true;
        
        // Wait a bit for visual feedback then shoot
        setTimeout(() => {
            shootStone();
            mouseDown = false;
            slingshotPulled = false;
        }, 100);

        // Visual feedback
        this.innerHTML = '🔥 FIRED!';
        this.style.background = 'linear-gradient(45deg, #00ff00, #00ff88)';
        
        setTimeout(() => {
            this.innerHTML = '🎯 AUTO SHOOT';
            this.style.background = 'linear-gradient(45deg, #ff0000, #ff6b00)';
        }, 500);
    };

    document.body.appendChild(hackButton);

    // Add info label
    const infoLabel = document.createElement('div');
    infoLabel.innerHTML = '⚠️ HACK MODE ACTIVE';
    infoLabel.style.cssText = `
        position: fixed;
        top: 60px;
        right: 20px;
        z-index: 10000;
        padding: 8px 15px;
        font-size: 14px;
        font-weight: bold;
        background: rgba(255, 0, 0, 0.8);
        color: white;
        border: 2px solid yellow;
        border-radius: 5px;
        animation: blink 1s infinite;
    `;

    // Add blinking animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
    `;
    document.head.appendChild(style);
    document.body.appendChild(infoLabel);

    console.log('%c🎯 AUTO-SHOOT HACK INJECTED! 🎯', 'color: red; font-size: 20px; font-weight: bold;');
    console.log('%cClick the AUTO SHOOT button to automatically aim and shoot at the mango!', 'color: orange; font-size: 14px;');
})();
