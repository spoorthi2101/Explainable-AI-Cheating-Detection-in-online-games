"""
Feature Extraction Script
Reads gameplay logs and computes behavioral features for ML detection
"""

import pandas as pd
import numpy as np
import os
import glob


def load_all_logs(logs_dir="logs"):
    """
    Load all player log files from the logs directory
    
    Returns:
        DataFrame with all gameplay events
    """
    log_files = glob.glob(os.path.join(logs_dir, "player_*.csv"))
    
    if not log_files:
        print(f"No log files found in {logs_dir}")
        return None
    
    print(f"Found {len(log_files)} log files")
    
    all_logs = []
    for log_file in log_files:
        try:
            df = pd.read_csv(log_file)
            all_logs.append(df)
            print(f"  Loaded: {os.path.basename(log_file)} ({len(df)} shots)")
        except Exception as e:
            print(f"  Error loading {log_file}: {e}")
    
    if not all_logs:
        return None
    
    combined_df = pd.concat(all_logs, ignore_index=True)
    print(f"\nTotal shots loaded: {len(combined_df)}")
    
    return combined_df


def extract_player_features(logs_df):
    """
    Extract behavioral features for each player
    
    Features computed:
    - accuracy: hit rate (0-1)
    - average_reaction_time: mean reaction time in ms
    - shots_per_second: shooting rate
    - average_mouse_speed: mean mouse movement speed
    - average_aim_snap: mean aim snap distance
    - distance_variance: variance in shot distances
    - label: 0 = NORMAL, 1 = ASSISTED
    
    Returns:
        DataFrame with one row per player
    """
    features_list = []
    
    # Check if required columns exist
    required_cols = ['player_id', 'hit']
    for col in required_cols:
        if col not in logs_df.columns:
            print(f"ERROR: Required column '{col}' not found in logs")
            print(f"Available columns: {logs_df.columns.tolist()}")
            return pd.DataFrame()
    
    # Group by player
    for player_id, player_df in logs_df.groupby('player_id'):
        
        # Basic statistics
        total_shots = len(player_df)
        total_hits = player_df['hit'].sum() if 'hit' in player_df.columns else 0
        
        # Skip if too few shots
        if total_shots < 5:
            print(f"Skipping {player_id}: only {total_shots} shots")
            continue
        
        # Feature 1: Accuracy
        accuracy = total_hits / total_shots if total_shots > 0 else 0
        
        # Feature 2: Average reaction time (handle missing column)
        if 'reaction_time_ms' in player_df.columns:
            avg_reaction_time = player_df['reaction_time_ms'].mean()
            if pd.isna(avg_reaction_time):
                avg_reaction_time = 0
        else:
            print(f"WARNING: 'reaction_time_ms' column not found for {player_id}")
            avg_reaction_time = 0
        
        # Feature 3: Shots per second
        # Calculate time span of gameplay
        if 'timestamp' in player_df.columns:
            player_df['timestamp'] = pd.to_datetime(player_df['timestamp'])
            time_span_seconds = (player_df['timestamp'].max() - player_df['timestamp'].min()).total_seconds()
            shots_per_second = total_shots / time_span_seconds if time_span_seconds > 0 else 0
        else:
            shots_per_second = 0
        
        # Feature 4: Average mouse speed (handle missing column)
        if 'mouse_speed' in player_df.columns:
            avg_mouse_speed = player_df['mouse_speed'].mean()
            if pd.isna(avg_mouse_speed):
                avg_mouse_speed = 0
        else:
            print(f"WARNING: 'mouse_speed' column not found for {player_id}")
            avg_mouse_speed = 0
        
        # Feature 5: Average aim snap distance (handle missing column)
        if 'aim_snap_distance' in player_df.columns:
            avg_aim_snap = player_df['aim_snap_distance'].mean()
            if pd.isna(avg_aim_snap):
                avg_aim_snap = 0
        else:
            print(f"WARNING: 'aim_snap_distance' column not found for {player_id}")
            avg_aim_snap = 0
        
        # Feature 6: Distance variance (handle missing column)
        if 'distance_to_target' in player_df.columns:
            distance_variance = player_df['distance_to_target'].var()
            if pd.isna(distance_variance):
                distance_variance = 0
        else:
            print(f"WARNING: 'distance_to_target' column not found for {player_id}")
            distance_variance = 0
        
        # Get player name if available
        if 'player_name' in player_df.columns:
            player_name = player_df['player_name'].iloc[0]
        else:
            player_name = player_id[:8]  # Fallback to shortened ID
        
        # Label: 0 = NORMAL, 1 = ASSISTED
        if 'game_mode' in player_df.columns:
            game_mode = player_df['game_mode'].iloc[0]
        else:
            print(f"WARNING: 'game_mode' column not found for {player_id}, assuming NORMAL")
            game_mode = "NORMAL"
        
        label = 1 if game_mode == "ASSISTED" else 0
        
        features = {
            'player_id': player_id,
            'player_name': player_name,
            'accuracy': accuracy,
            'average_reaction_time': avg_reaction_time,
            'shots_per_second': shots_per_second,
            'average_mouse_speed': avg_mouse_speed,
            'average_aim_snap': avg_aim_snap,
            'distance_variance': distance_variance,
            'label': label,
            'total_shots': total_shots,
            'game_mode': game_mode
        }
        
        features_list.append(features)
        
        # Print summary
        print(f"\n{player_id} ({game_mode}):")
        print(f"  Shots: {total_shots}, Hits: {total_hits}, Accuracy: {accuracy:.2%}")
        print(f"  Avg Reaction Time: {avg_reaction_time:.1f}ms")
        print(f"  Shots/sec: {shots_per_second:.2f}")
        print(f"  Avg Mouse Speed: {avg_mouse_speed:.2f}")
        print(f"  Avg Aim Snap: {avg_aim_snap:.2f}")
    
    features_df = pd.DataFrame(features_list)
    return features_df


def save_features(features_df, output_file="data/features.csv"):
    """
    Save extracted features to CSV file
    """
    # Create data directory if it doesn't exist
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    features_df.to_csv(output_file, index=False)
    print(f"\n{'='*50}")
    print(f"Features saved to: {output_file}")
    print(f"Total players: {len(features_df)}")
    print(f"Normal players: {(features_df['label'] == 0).sum()}")
    print(f"Assisted players: {(features_df['label'] == 1).sum()}")
    print(f"{'='*50}")


def main():
    """
    Main feature extraction pipeline
    """
    print("="*50)
    print("FEATURE EXTRACTION")
    print("="*50)
    
    # Step 1: Load all logs
    print("\n[1/3] Loading gameplay logs...")
    logs_df = load_all_logs("logs")
    
    if logs_df is None or logs_df.empty:
        print("ERROR: No logs to process. Play some games first!")
        return
    
    # Step 2: Extract features
    print("\n[2/3] Extracting features...")
    features_df = extract_player_features(logs_df)
    
    if features_df.empty:
        print("ERROR: No features extracted")
        return
    
    # Step 3: Save features
    print("\n[3/3] Saving features...")
    save_features(features_df, "data/features.csv")
    
    print("\nFeature extraction complete!")
    print("\nNext steps:")
    print("1. Run model/train_model.py to train the detection model")
    print("2. Run dashboard/app.py to view results")


if __name__ == "__main__":
    main()
