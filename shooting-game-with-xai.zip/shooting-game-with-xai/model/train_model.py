"""
Machine Learning Detection Model
Trains a RandomForest classifier to detect non-human gameplay behavior
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, classification_report, confusion_matrix
import joblib
import os


def load_features(features_file="data/features.csv"):
    """
    Load the extracted features dataset
    """
    if not os.path.exists(features_file):
        print(f"ERROR: Features file not found: {features_file}")
        print("Please run model/extract_features.py first!")
        return None
    
    df = pd.read_csv(features_file)
    print(f"Loaded {len(df)} player records")
    print(f"Features: {df.columns.tolist()}")
    
    return df


def prepare_data(df):
    """
    Prepare features and labels for training
    
    Returns:
        X: Feature matrix
        y: Labels (0=Normal, 1=Assisted)
        feature_names: List of feature column names
    """
    # Define feature columns
    feature_columns = [
        'accuracy',
        'average_reaction_time',
        'shots_per_second',
        'average_mouse_speed',
        'average_aim_snap',
        'distance_variance'
    ]
    
    # Extract features and labels
    X = df[feature_columns].values
    y = df['label'].values
    
    print(f"\nDataset shape: {X.shape}")
    print(f"Class distribution:")
    print(f"  Normal (0): {(y == 0).sum()}")
    print(f"  Assisted (1): {(y == 1).sum()}")
    
    return X, y, feature_columns


def train_model(X, y):
    """
    Train a RandomForest classifier
    
    Returns:
        model: Trained classifier
        X_train, X_test, y_train, y_test: Split datasets
    """
    # Check if we have enough samples for proper train/test split
    min_samples_per_class = min(np.bincount(y.astype(int)))
    
    if len(X) < 4 or min_samples_per_class < 2:
        # Too few samples - train on all data, use same for testing
        print(f"\n⚠️  WARNING: Only {len(X)} samples with {min_samples_per_class} per class")
        print("Training on all data without train/test split")
        print("This is OK for demo purposes, but collect more data for production!")
        
        X_train = X_test = X
        y_train = y_test = y
        
        # Use simpler model for small datasets
        model = RandomForestClassifier(
            n_estimators=50,
            max_depth=5,
            min_samples_split=2,
            min_samples_leaf=1,
            random_state=42,
            n_jobs=-1
        )
    elif len(X) < 10:
        # Small dataset - split without stratification
        print(f"\nWARNING: Only {len(X)} samples")
        print("Using train/test split WITHOUT stratification")
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=None
        )
        
        print(f"Train set: {len(X_train)} samples")
        print(f"Test set: {len(X_test)} samples")
        
        model = RandomForestClassifier(
            n_estimators=50,
            max_depth=8,
            min_samples_split=2,
            min_samples_leaf=1,
            random_state=42,
            n_jobs=-1
        )
    else:
        # Normal case - enough data for proper split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )
        
        print(f"\nTrain set: {len(X_train)} samples")
        print(f"Test set: {len(X_test)} samples")
        
        # Train RandomForest classifier
        model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
    
    print("\nTraining RandomForest classifier...")
    model.fit(X_train, y_train)
    print("Training complete!")
    
    return model, X_train, X_test, y_train, y_test


def evaluate_model(model, X_train, X_test, y_train, y_test, feature_names):
    """
    Evaluate model performance and print metrics
    """
    # Predictions
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    
    # Calculate metrics
    train_accuracy = accuracy_score(y_train, y_train_pred)
    test_accuracy = accuracy_score(y_test, y_test_pred)
    
    test_precision = precision_score(y_test, y_test_pred, zero_division=0)
    test_recall = recall_score(y_test, y_test_pred, zero_division=0)
    
    print("\n" + "="*50)
    print("MODEL PERFORMANCE")
    print("="*50)
    
    print(f"\nTrain Accuracy: {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    print(f"Test Accuracy:  {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    print(f"Test Precision: {test_precision:.4f} ({test_precision*100:.2f}%)")
    print(f"Test Recall:    {test_recall:.4f} ({test_recall*100:.2f}%)")
    
    print("\nConfusion Matrix:")
    cm = confusion_matrix(y_test, y_test_pred, labels=[0, 1])
    print(cm)
    print("         Predicted")
    print("         Normal  Assisted")
    
    # Handle cases where only one class is present
    if cm.shape == (2, 2):
        print(f"Normal    {cm[0][0]:4d}    {cm[0][1]:4d}")
        print(f"Assisted  {cm[1][0]:4d}    {cm[1][1]:4d}")
    else:
        print("Note: Only one class present in test data")
        print(f"Values: {cm.flatten()}")
    
    print("\nClassification Report:")
    print(classification_report(y_test, y_test_pred, 
                                labels=[0, 1],
                                target_names=['Normal', 'Assisted'],
                                zero_division=0))
    
    # Feature importance
    print("\nFeature Importance:")
    feature_importance = pd.DataFrame({
        'feature': feature_names,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)
    
    for idx, row in feature_importance.iterrows():
        print(f"  {row['feature']:25s}: {row['importance']:.4f}")
    
    return test_accuracy, test_precision, test_recall


def save_model(model, model_file="model/detection_model.pkl"):
    """
    Save trained model to disk
    """
    os.makedirs(os.path.dirname(model_file), exist_ok=True)
    joblib.dump(model, model_file)
    print(f"\n{'='*50}")
    print(f"Model saved to: {model_file}")
    print(f"{'='*50}")


def main():
    """
    Main training pipeline
    """
    print("="*50)
    print("ML DETECTION MODEL TRAINING")
    print("="*50)
    
    # Step 1: Load features
    print("\n[1/5] Loading features...")
    df = load_features("data/features.csv")
    
    if df is None or df.empty:
        print("ERROR: No features to train on")
        return
    
    # Check minimum samples
    if len(df) < 10:
        print(f"WARNING: Only {len(df)} samples. Recommend at least 10 players.")
        print("Play more games in both NORMAL and ASSISTED modes!")
    
    # Step 2: Prepare data
    print("\n[2/5] Preparing data...")
    X, y, feature_names = prepare_data(df)
    
    # Step 3: Train model
    print("\n[3/5] Training model...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    # Step 4: Evaluate model
    print("\n[4/5] Evaluating model...")
    evaluate_model(model, X_train, X_test, y_train, y_test, feature_names)
    
    # Step 5: Save model
    print("\n[5/5] Saving model...")
    save_model(model, "model/detection_model.pkl")
    
    print("\n" + "="*50)
    print("Model training complete!")
    print("\nNext step:")
    print("Run: streamlit run dashboard/app.py")
    print("="*50)


if __name__ == "__main__":
    main()
