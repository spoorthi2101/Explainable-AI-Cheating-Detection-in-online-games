"""
Admin Dashboard with XAI
Streamlit dashboard for viewing detection results and SHAP explanations
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import shap
import matplotlib.pyplot as plt
import seaborn as sns


# Page configuration
st.set_page_config(
    page_title="Anti-Cheat Detection Dashboard",
    page_icon="🎮",
    layout="wide"
)


@st.cache_resource
def load_model(model_path="model/detection_model.pkl"):
    """Load the trained detection model"""
    if not os.path.exists(model_path):
        return None
    return joblib.load(model_path)


@st.cache_data
def load_features(features_path="data/features.csv"):
    """Load player features dataset"""
    if not os.path.exists(features_path):
        return None
    df = pd.read_csv(features_path)
    
    # Handle NaN values
    # Replace NaN with 0 for numeric columns
    numeric_cols = ['accuracy', 'average_reaction_time', 'shots_per_second', 
                    'average_mouse_speed', 'average_aim_snap', 'distance_variance']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = df[col].fillna(0)
    
    # Drop rows where all features are 0 or NaN
    df = df.dropna(subset=['player_id'])
    
    return df


@st.cache_resource
def create_shap_explainer(_model, X_train):
    """Create SHAP explainer (cached for performance)"""
    return shap.TreeExplainer(_model)


def get_behavioral_score(features, model):
    """
    Calculate behavioral detection score (0-1)
    Uses ML model probability
    """
    feature_columns = [
        'accuracy',
        'average_reaction_time',
        'shots_per_second',
        'average_mouse_speed',
        'average_aim_snap',
        'distance_variance'
    ]
    
    # Handle NaN values - convert to numeric and fill
    X = features[feature_columns].apply(pd.to_numeric, errors='coerce').fillna(0).astype(float).values.reshape(1, -1)
    
    # Check if all features are 0 (invalid data)
    if np.all(X == 0):
        return 0.0
    
    prob = model.predict_proba(X)[0][1]  # Probability of class 1 (ASSISTED)
    
    return prob


def get_assisted_mode_score(features):
    """
    Calculate assisted mode indicator score (0-1)
    Based on key assisted-mode characteristics
    """
    # Key indicators of assisted mode
    score = 0.0
    
    # Handle NaN values
    reaction_time = features.get('average_reaction_time', 0) or 0
    accuracy = features.get('accuracy', 0) or 0
    aim_snap = features.get('average_aim_snap', 0) or 0
    
    # Very low reaction time (< 100ms is suspicious)
    if reaction_time > 0 and reaction_time < 100:
        score += 0.4
    
    # Very high accuracy (> 90% is suspicious)
    if accuracy > 0.90:
        score += 0.3
    
    # Very low aim snap (< 10 pixels suggests auto-aim)
    if aim_snap > 0 and aim_snap < 10:
        score += 0.3
    
    return min(score, 1.0)


def calculate_multi_view_score(features, model):
    """
    Multi-view detection combining behavioral ML and assisted-mode indicators
    
    Final score = 0.8 * behavioral_score + 0.2 * assisted_score
    """
    behavioral_score = get_behavioral_score(features, model)
    assisted_score = get_assisted_mode_score(features)
    
    # Weighted combination
    final_score = 0.8 * behavioral_score + 0.2 * assisted_score
    
    return final_score, behavioral_score, assisted_score


def generate_text_explanation(features, shap_values, feature_names):
    """
    Generate human-readable explanation for detection
    """
    import numpy as np
    
    # Ensure shap_values is a 1D numpy array
    shap_vals = np.array(shap_values).flatten()
    
    # Get top contributing features
    feature_contributions = [(name, float(val)) for name, val in zip(feature_names, shap_vals)]
    feature_contributions.sort(key=lambda x: abs(x[1]), reverse=True)
    
    explanation_parts = []
    
    # Check key suspicious behaviors
    if features['average_reaction_time'] < 100:
        explanation_parts.append(
            f"⚠️ **Extremely low reaction time** ({features['average_reaction_time']:.1f}ms) - "
            f"typical humans react in 150-300ms"
        )
    
    if features['accuracy'] > 0.90:
        explanation_parts.append(
            f"⚠️ **Unusually high accuracy** ({features['accuracy']*100:.1f}%) - "
            f"suggests automated targeting"
        )
    
    if features['average_aim_snap'] < 10:
        explanation_parts.append(
            f"⚠️ **Near-zero aim snap distance** ({features['average_aim_snap']:.1f} pixels) - "
            f"indicates instant target lock"
        )
    
    if features['shots_per_second'] > 2:
        explanation_parts.append(
            f"⚠️ **High shooting rate** ({features['shots_per_second']:.2f} shots/sec) - "
            f"unusually fast for human players"
        )
    
    # Add top SHAP features
    explanation_parts.append("\n**Top contributing features:**")
    for feature, value in feature_contributions[:3]:
        explanation_parts.append(f"  • {feature}: {value:.4f}")
    
    return "\n\n".join(explanation_parts)


def plot_shap_waterfall(shap_values, feature_values, feature_names, player_id):
    """
    Create SHAP waterfall plot showing feature contributions
    """
    import numpy as np
    
    # Ensure all arrays are proper 1D and same length
    shap_values = np.array(shap_values).flatten()
    feature_values = np.array(feature_values).flatten()
    feature_names = list(feature_names)
    
    # Ensure all same length
    min_len = min(len(shap_values), len(feature_values), len(feature_names))
    shap_values = shap_values[:min_len]
    feature_values = feature_values[:min_len]
    feature_names = feature_names[:min_len]
    
    # Create explanation object for waterfall plot
    explanation = shap.Explanation(
        values=shap_values,
        base_values=0,  # Will be set by explainer
        data=feature_values,
        feature_names=feature_names
    )
    
    fig, ax = plt.subplots(figsize=(10, 6))
    shap.plots.waterfall(explanation, show=False)
    plt.title(f"SHAP Explanation for {player_id}", fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    return fig


def plot_feature_importance(model, feature_names):
    """
    Plot feature importance from the model
    """
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': model.feature_importances_
    }).sort_values('Importance', ascending=True)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(importance_df['Feature'], importance_df['Importance'], color='steelblue')
    ax.set_xlabel('Importance Score', fontsize=12)
    ax.set_title('Feature Importance in Detection Model', fontsize=14, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    
    return fig


def main():
    """
    Main dashboard application
    """
    st.title("🎮 Anti-Cheat Detection Dashboard")
    st.markdown("### Explainable AI for Detecting Non-Human Gameplay Behavior")
    st.markdown("---")
    
    # Load model and data
    model = load_model("model/detection_model.pkl")
    features_df = load_features("data/features.csv")
    
    # Check if data is available
    if model is None:
        st.error("❌ Detection model not found!")
        st.info("Please train the model first by running: `python model/train_model.py`")
        return
    
    if features_df is None or features_df.empty:
        st.error("❌ No player data found!")
        st.info("Please extract features first by running: `python model/extract_features.py`")
        return
    
    # Feature columns
    feature_columns = [
        'accuracy',
        'average_reaction_time',
        'shots_per_second',
        'average_mouse_speed',
        'average_aim_snap',
        'distance_variance'
    ]
    
    # Calculate detection scores for all players
    detection_results = []
    
    for idx, row in features_df.iterrows():
        final_score, behavioral_score, assisted_score = calculate_multi_view_score(row, model)
        
        # Override: If game_mode is ASSISTED, set confidence to 95% (explicit detection)
        if row['game_mode'] == 'ASSISTED':
            final_score = 0.95
        
        # Classification
        if final_score > 0.7:
            status = "🚨 Suspicious"
            status_color = "red"
        elif final_score > 0.4:
            status = "⚠️ Warning"
            status_color = "orange"
        else:
            status = "✅ Normal"
            status_color = "green"
        
        # Use actual player name if available
        player_name = row.get('player_name', row['player_id'][:8])
        
        detection_results.append({
            'player_id': row['player_id'],
            'player_name': player_name,
            'game_mode': row['game_mode'],
            'status': status,
            'status_color': status_color,
            'confidence': final_score,
            'behavioral_score': behavioral_score,
            'assisted_score': assisted_score,
            'accuracy': row['accuracy'],
            'reaction_time': row['average_reaction_time'],
            'shots': row['total_shots']
        })
    
    results_df = pd.DataFrame(detection_results)
    
    # Sidebar - Overview
    st.sidebar.header("📊 Overview")
    st.sidebar.metric("Total Players", len(results_df))
    st.sidebar.metric("Suspicious Players", len(results_df[results_df['status'].str.contains("Suspicious")]))
    st.sidebar.metric("Normal Players", len(results_df[results_df['status'].str.contains("Normal")]))
    
    st.sidebar.markdown("---")
    st.sidebar.header("ℹ️ Detection Thresholds")
    st.sidebar.write("**Confidence Score:**")
    st.sidebar.write("- < 0.4: Normal")
    st.sidebar.write("- 0.4 - 0.7: Warning")
    st.sidebar.write("- > 0.7: Suspicious")
    
    # Main content - Player list
    st.header("👥 Player Detection Results")
    
    # Display player table
    display_df = results_df[['player_name', 'status', 'confidence', 'accuracy', 'reaction_time', 'shots']].copy()
    display_df['confidence'] = display_df['confidence'].apply(lambda x: f"{x:.2%}")
    display_df['accuracy'] = display_df['accuracy'].apply(lambda x: f"{x:.2%}")
    display_df['reaction_time'] = display_df['reaction_time'].apply(lambda x: f"{x:.1f}ms")
    
    st.dataframe(
        display_df,
        width='stretch',
        hide_index=True
    )
    
    st.markdown("---")
    
    # Player selection for detailed view
    st.header("🔍 Detailed Player Analysis")
    
    selected_player = st.selectbox(
        "Select a player to analyze:",
        options=results_df['player_id'].tolist(),
        format_func=lambda x: f"{results_df[results_df['player_id']==x]['player_name'].iloc[0]} ({x[:8]}) - {results_df[results_df['player_id']==x]['status'].iloc[0]}"
    )
    
    if selected_player:
        # Get player data
        player_result = results_df[results_df['player_id'] == selected_player].iloc[0]
        player_features = features_df[features_df['player_id'] == selected_player].iloc[0]
        
        # Display player info
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Status", player_result['status'])
        with col2:
            st.metric("Confidence", f"{player_result['confidence']:.2%}")
        with col3:
            st.metric("Total Shots", int(player_result['shots']))
        
        st.markdown("---")
        
        # Two-column layout for details
        col_left, col_right = st.columns(2)
        
        with col_left:
            st.subheader("📈 Gameplay Statistics")
            
            stats_data = {
                'Metric': [
                    'Accuracy',
                    'Avg Reaction Time',
                    'Shots per Second',
                    'Avg Mouse Speed',
                    'Avg Aim Snap',
                    'Distance Variance'
                ],
                'Value': [
                    f"{player_features['accuracy']:.2%}",
                    f"{player_features['average_reaction_time']:.1f} ms",
                    f"{player_features['shots_per_second']:.2f}",
                    f"{player_features['average_mouse_speed']:.2f}",
                    f"{player_features['average_aim_snap']:.2f} px",
                    f"{player_features['distance_variance']:.2f}"
                ]
            }
            
            st.table(pd.DataFrame(stats_data))
            
            # Multi-view scores
            st.subheader("🎯 Multi-View Detection Scores")
            st.write(f"**Behavioral ML Score:** {player_result['behavioral_score']:.2%}")
            st.progress(player_result['behavioral_score'])
            
            st.write(f"**Assisted Mode Score:** {player_result['assisted_score']:.2%}")
            st.progress(player_result['assisted_score'])
            
            st.write(f"**Final Combined Score:** {player_result['confidence']:.2%}")
            st.progress(player_result['confidence'])
        
        with col_right:
            st.subheader("🧠 XAI Explanation")
            
            # Generate SHAP values
            import numpy as np
            X_player = player_features[feature_columns].values.reshape(1, -1)
            
            # Create explainer
            explainer = create_shap_explainer(model, features_df[feature_columns].values)
            shap_values = explainer.shap_values(X_player)
            
            # For binary classification, shap_values might be a list
            if isinstance(shap_values, list):
                # For binary classification, use the positive class (ASSISTED)
                shap_values_plot = np.array(shap_values[1]).flatten()
            else:
                shap_values_plot = np.array(shap_values).flatten()
            
            # Ensure correct length
            if len(shap_values_plot) != len(feature_columns):
                st.error(f"SHAP values length mismatch: {len(shap_values_plot)} vs {len(feature_columns)} features")
                shap_values_plot = shap_values_plot[:len(feature_columns)]
            
            # Text explanation
            explanation_text = generate_text_explanation(
                player_features[feature_columns],
                shap_values_plot,
                feature_columns
            )
            
            st.markdown(explanation_text)
        
        # SHAP visualization
        st.markdown("---")
        st.subheader("📊 SHAP Feature Contribution Plot")
        
        try:
            # Create waterfall plot
            fig_waterfall = plot_shap_waterfall(
                shap_values_plot,
                X_player[0],
                feature_columns,
                selected_player
            )
            st.pyplot(fig_waterfall)
        except Exception as e:
            st.warning(f"Could not generate SHAP waterfall plot: {e}")
            
            # Fallback: Show bar chart of SHAP values
            st.write("**SHAP Values (Feature Contributions):**")
            # Ensure arrays are same length
            min_len = min(len(feature_columns), len(shap_values_plot))
            shap_df = pd.DataFrame({
                'Feature': list(feature_columns)[:min_len],
                'SHAP Value': list(shap_values_plot)[:min_len]
            }).sort_values('SHAP Value', key=abs, ascending=False)
            
            fig, ax = plt.subplots(figsize=(10, 6))
            colors = ['red' if x > 0 else 'blue' for x in shap_df['SHAP Value']]
            ax.barh(shap_df['Feature'], shap_df['SHAP Value'], color=colors)
            ax.set_xlabel('SHAP Value (impact on prediction)')
            ax.set_title(f'Feature Contributions for {selected_player}')
            ax.axvline(x=0, color='black', linestyle='-', linewidth=0.5)
            plt.tight_layout()
            st.pyplot(fig)
    
    # Model insights section
    st.markdown("---")
    st.header("🔬 Model Insights")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Feature Importance")
        fig_importance = plot_feature_importance(model, feature_columns)
        st.pyplot(fig_importance)
    
    with col2:
        st.subheader("Detection Statistics")
        
        # Count by status
        status_counts = results_df['status'].value_counts()
        
        fig, ax = plt.subplots(figsize=(8, 6))
        colors_map = {
            '✅ Normal': 'green',
            '⚠️ Warning': 'orange',
            '🚨 Suspicious': 'red'
        }
        colors = [colors_map.get(status, 'gray') for status in status_counts.index]
        
        ax.pie(status_counts.values, labels=status_counts.index, autopct='%1.1f%%',
               colors=colors, startangle=90)
        ax.set_title('Player Status Distribution')
        st.pyplot(fig)
    
    # Footer
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "Academic Prototype - Explainable AI for Robust Multi-View Detection<br>"
        "Built with Streamlit, scikit-learn, and SHAP"
        "</div>",
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    main()
