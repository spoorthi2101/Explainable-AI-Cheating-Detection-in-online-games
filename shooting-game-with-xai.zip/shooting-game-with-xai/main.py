"""
Main Entry Point for Mango Slingshot Game with AI Detection
"""

import sys
import os


def print_menu():
    """Display main menu"""
    print("\n" + "="*60)
    print("  🥭 2D MANGO SLINGSHOT GAME + AI DETECTION")
    print("="*60)
    print("\nSelect an option:")
    print("\n1. 🥭 Play 2D Multiplayer Mango Slingshot Game")
    print("2. 📊 Extract Features from Logs")
    print("3. 🧠 Train Detection Model")
    print("4. 📈 Launch Admin Dashboard")
    print("5. 🚀 Run Complete Pipeline")
    print("\n0. Exit")
    print("\n" + "="*60)


def extract_features():
    """Extract features from gameplay logs"""
    print("\nExtracting features from logs...")
    os.system("python model/extract_features.py")


def train_model():
    """Train the ML detection model"""
    print("\nTraining detection model...")
    os.system("python model/train_model.py")


def launch_dashboard():
    """Launch Streamlit dashboard"""
    print("\nLaunching admin dashboard...")
    print("Dashboard will open in your browser at http://localhost:8501")
    os.system("streamlit run dashboard/app.py")


def run_web_game():
    """Run the web-based 2D multiplayer mango slingshot game"""
    print("\nLaunching 2D multiplayer mango slingshot game server...")
    print("Server will start at http://localhost:5000")
    print("Open the URL in your web browser to play!")
    print("\nMultiple players can join from different browsers.")
    input("\nPress Enter to start the server...")
    os.system("python server/app.py")


def run_complete_pipeline():
    """Run the complete pipeline for demo"""
    print("\n" + "="*60)
    print("RUNNING COMPLETE PIPELINE")
    print("="*60)
    
    print("\nThis demo will:")
    print("1. Extract features from existing logs")
    print("2. Train the detection model")
    print("3. Launch the dashboard")
    
    input("\nPress Enter to continue...")
    
    # Step 1: Extract features
    print("\n[Step 1/3] Extracting features...")
    os.system("python model/extract_features.py")
    
    # Step 2: Train model
    print("\n[Step 2/3] Training model...")
    os.system("python model/train_model.py")
    
    # Step 3: Launch dashboard
    print("\n[Step 3/3] Launching dashboard...")
    launch_dashboard()


def main():
    """Main entry point"""
    while True:
        print_menu()
        
        try:
            choice = input("\nEnter your choice: ").strip()
            
            if choice == "1":
                run_web_game()
                
            elif choice == "2":
                extract_features()
                input("\nPress Enter to continue...")
                
            elif choice == "3":
                train_model()
                input("\nPress Enter to continue...")
                
            elif choice == "4":
                launch_dashboard()
                break  # Exit after launching dashboard
                
            elif choice == "5":
                run_complete_pipeline()
                break
                
            elif choice == "0":
                print("\nExiting... Goodbye!")
                sys.exit(0)
                
            else:
                print("\n❌ Invalid choice. Please try again.")
                
        except KeyboardInterrupt:
            print("\n\nInterrupted. Exiting...")
            sys.exit(0)
        except Exception as e:
            print(f"\n❌ Error: {e}")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()
