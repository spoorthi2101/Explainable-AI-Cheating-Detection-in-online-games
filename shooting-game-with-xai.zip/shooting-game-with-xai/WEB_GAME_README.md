# 🥭 2D Multiplayer Mango Slingshot Game

## Quick Start

```bash
# Windows
start_web_game.bat

# Linux/Mac
./start_web_game.sh
```

Open **http://localhost:5000** in your browser.

## Features

- ✅ **2D slingshot mechanics** - Drag and release
- ✅ **Multiplayer rooms** (up to 8 players)
- ✅ **Real-time sync** via WebSocket
- ✅ **Physics-based projectiles** with gravity
- ✅ **Live scoreboard** and hit detection
- ✅ **Web-based** - no installation needed

## Controls

- **Mouse** - Aim slingshot
- **Click + Drag** - Pull rubber band
- **Release** - Shoot stone

## How to Play

1. Enter your name
2. Create a room or join existing one
3. Wait for other players (or start solo)
4. Click "Start Game"
5. Aim and shoot mangos!

## Project Structure

```
web-game/
├── templates/
│   └── index.html      # Game UI
└── static/
    └── js/
        └── game.js     # Game logic
```

## Technical Details

- **Frontend:** HTML5 Canvas, JavaScript
- **Backend:** Flask-SocketIO (Python)
- **Communication:** Socket.io WebSocket
- **Physics:** Custom 2D projectile simulation

## 🔧 Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Run the game
python server/app.py
# OR
./start_web_game.bat
```

---

## 🎮 How to Play Multiplayer

1. **Start the server** (see Quick Start)
2. **Open http://localhost:5000** in your browser
3. **Enter your name**
4. **Create a room** or **join existing room**
5. **Wait for other players** (or play solo)
6. **Click "Start Game"**
7. **Draw your bow** (hold left click) and **shoot arrows**!

### Tips
- Draw the bow fully for maximum power and distance
- Lead your shots - arrows have realistic physics with gravity
- Aim for the center of targets for maximum points
- Watch out for other players in PvP mode!

---

## 🤖 XAI Anti-Cheat Integration

All gameplay is automatically logged with telemetry:
- Arrow shot positions and timings
- Hit accuracy and patterns
- Mouse movement behavior
- Reaction times

Use the existing ML pipeline to analyze for suspicious behavior:
```bash
python main.py
# Options 4-7 for feature extraction, training, and dashboard
```


