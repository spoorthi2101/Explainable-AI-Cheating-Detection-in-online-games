# 🥭 2D Multiplayer Mango Slingshot Game

## Overview

A real-time multiplayer 2D slingshot game where players shoot mangos off a tree. Features include telemetry collection and AI-based gameplay analysis.

### Features

✅ **2D slingshot mechanics** - Drag and release to shoot  
✅ **Real-time multiplayer** - Up to 8 players per room  
✅ **Web-based** - No installation needed  
✅ **AI detection** - ML model for gameplay analysis  
✅ **Admin dashboard** - Real-time monitoring and analytics

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Launch game
python main.py
# OR
./start_web_game.bat  # Windows
./start_web_game.sh   # Linux/Mac
```

Open **http://localhost:5000** in your browser.

### Controls
- **Mouse** - Aim slingshot
- **Click + Drag** - Pull rubber band
- **Release** - Shoot stone

## Architecture

```
Web Client (Browser)
├─ 2D Canvas rendering
├─ Slingshot physics
└─ Socket.io multiplayer sync
         ↓
Python Backend (Flask-SocketIO)
├─ Game rooms & matchmaking
├─ Hit detection & scoring
└─ Telemetry logging
         ↓
ML Detection (RandomForest + SHAP)
├─ Feature extraction
├─ Bot detection
└─ Explainability
         ↓
Admin Dashboard (Streamlit)
└─ Monitoring & analytics
```

## Project Structure

```
shooting-game-with-xai/
├── server/app.py              # Backend server
├── web-game/                  # Frontend game
│   ├── templates/index.html
│   └── static/js/game.js
├── model/                     # ML detection
│   ├── extract_features.py
│   └── train_model.py
├── dashboard/app.py           # Admin dashboard
├── logs/                      # Telemetry data
├── auto-shoot-hack.js         # Demo hack script
└── main.py                    # Launcher
```

## Technologies

- **Frontend:** HTML5 Canvas, JavaScript, Socket.io
- **Backend:** Python, Flask-SocketIO
- **ML:** scikit-learn, SHAP, pandas
- **Dashboard:** Streamlit

## Development

```bash
# Run backend
python server/app.py

# Run dashboard
streamlit run dashboard/app.py

# Train model
python model/train_model.py
```

## Demo Hack Script

For testing/demo purposes, a console-injectable auto-aim script is provided:

```bash
# Open game in browser
# Press F12 (DevTools)
# Copy contents of auto-shoot-hack.js
# Paste in Console and press Enter
# Click the "AUTO SHOOT" button
```

This demonstrates how client-side games can be exploited and why server-side validation + AI detection is necessary.
- Python 3.x
- Flask (web framework)
- Flask-SocketIO (WebSocket server)
- Flask-CORS (cross-origin support)

**ML/XAI:**
- Pandas, NumPy (data processing)
- Scikit-learn (RandomForest, preprocessing)
- SHAP (model explainability)
- Streamlit (interactive dashboard)
- Matplotlib, Seaborn (visualizations)

---

## 🎯 How to Play Multiplayer

1. **Start the server**: `python server/app.py`
2. **Open browser**: Navigate to http://localhost:5000
3. **Enter your name**
4. **Create room** or **join existing room**
5. **Wait for players** (or start solo)
6. **Click "Start Game"**
7. **Hold left click** to draw bow, **release** to shoot!

### Tips for Players
- Longer bow draw = more power and distance
- Arrows follow realistic physics (drop over distance)
- Aim slightly above distant targets
- Lead moving targets
- 100 points for target destruction, 50 for player hits

---

## 🛠️ Development

### Run in Development Mode

```bash
# Backend (with hot reload)
python server/app.py

# Dashboard
streamlit run dashboard/app.py
```

### Generate Sample Data

Play a few games to generate telemetry, then:
```bash
python model/extract_features.py
python model/train_model.py
```

---

## 🐛 Troubleshooting

**"Port already in use"**
```bash
# Kill process on port 5000
# Windows: netstat -ano | findstr :5000
# Linux: lsof -ti:5000 | xargs kill
```

**"Module not found"**
```bash
pip install -r requirements.txt
```

**Browser connection issues**
- Check firewall settings
- Try http://127.0.0.1:5000 instead of localhost
- Ensure port 5000 is not blocked

**Players not syncing**
- Clear browser cache
- Check browser console (F12) for errors
- Ensure all players are in the same room

---

## 📝 Academic Context

This project demonstrates:
- Real-time multiplayer game architecture
- Behavioral telemetry collection
- Machine learning for anomaly detection
- Explainable AI (XAI) for interpretability
- Full-stack web development (Python + JavaScript)

**Use Case**: Detecting automated gameplay (bots, aimbots, macros) in online games using explainable ML models.

---

## License

MIT License - Free to use and modify.
   streamlit run dashboard/app.py
   ```

4. **Verify Detection:**
   - ASSISTED players should be flagged as suspicious
   - NORMAL players should show as normal
   - SHAP explanations should highlight reaction time and accuracy

---

## 🛠️ Technology Stack

| Component | Technology | Purpose |mango slingshot
|-----------|-----------|---------|
| **Game Client** | Three.js + Flask-SocketIO | 3D multiplayer archery game |
| **Data Processing** | Pandas, NumPy | Log parsing and feature extraction |
| **Machine Learning** | scikit-learn | RandomForest classifier |
| **Explainability** | SHAP | Model interpretation and explanations |
| **Dashboard** | Streamlit | Interactive web-based admin panel |
| **Visualization** | Matplotlib, Seaborn | Charts and plots |

**System Requirements:**
- CPU only (no GPU required)
- Lightweight and fast
- Runs on Windows, macOS, Linux

---

## 📝 Key Features

✅ **Dual Gameplay Modes** - Normal vs Assisted  
✅ **Automatic Logging** - All shots logged to CSV  
✅ **Feature Engineering** - 6 behavioral features  
✅ **ML Detection** - RandomForest classifier  
✅ **Multi-View Approach** - Combined ML + rule-based  
✅ **Explainable AI** - SHAP explanations for all decisions  
✅ **Interactive Dashboard** - Beautiful Streamlit interface  
✅ **Real-time Analysis** - Instant detection results  
✅ **Educational** - Clean, commented, beginner-friendly code  

---

## 🔒 Ethical Considerations

This project is designed for **academic and research purposes only**:

1. **No real cheating involved** - Assisted mode is simulated internally
2. **No external game modification** - Standalone system
3. **Educational purpose** - Demonstrates ML and XAI concepts
4. **Transparent** - All code is open and documented
5. **Controlled environment** - No impact on real games or players

---

## 📚 Academic Context

**Project Title:**  
"Explainable AI for Robust Multi-View Detection of Non-Human Gameplay Behavior in Online Games"

**Research Questions:**
1. Can ML models detect non-human gameplay patterns?
2. How effective is multi-view detection (ML + rules)?
3. Can XAI provide interpretable explanations for detection?

**Methodology:**
- Experimental game environment
- Controlled data collection
- Supervised learning with labeled data
- SHAP-based model interpretation
- Performance evaluation

---

## 🐛 Troubleshooting

### Issue: "No module named 'pygame'"
**Solution:** Install dependencies
```bash
pip install -r requirements.txt
```

### Issue: "No log files found"
**Solution:** Play some games first
```bash
python game/game.py
```

### Issue: "Model not found"
**Solution:** Train the model first
```bash
python model/extract_features.py
python model/train_model.py
```

### Issue: Game runs too slow
**Solution:** Reduce FPS in game.py (line with `FPS = 60`)

### Issue: Not enough training data
**Solution:** Play at least 5 games total (mix of both modes)

---

## 📜 License

Educational use only. Not for commercial purposes.

---

## 🙏 Acknowledgments

- **Pygame** - Game development framework
- **scikit-learn** - Machine learning library
- **SHAP** - Explainable AI framework
- **Streamlit** - Dashboard framework

---

## 📞 Support

For questions or issues related to this academic project, please refer to the code comments and documentation within each module.

**Key Files to Review:**
- [game/game.py](game/game.py) - Game implementation
- [model/extract_features.py](model/extract_features.py) - Feature extraction
- [model/train_model.py](model/train_model.py) - ML training
- [dashboard/app.py](dashboard/app.py) - Dashboard and XAI

---

**Happy Testing! 🎮🤖🔍**
